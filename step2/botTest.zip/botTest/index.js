'use strict';

exports.handler = function (event, context, callback) {
    var operationMessage = "あなたの名前、年齢、出身、趣味について紹介できます。";
    operationMessage += "何から紹介しましょうか？";
    const endMessage = 'さようなら。もっと知りたい時は直接たくさんお話しましょう！';
    const notFoundMessage = "私には紹介できません。";
        
// LINEの設定を読みこむ*********************************************************
    const line = require('@line/bot-sdk');
    const config = {
        channelSecret: '0476073354f2be1ece014d3b9bb60338',
        channelAccessToken: 'SeBgG477cAuX7rEE1rwoGyq0xQtqayA5rlLCEXa6YhUv2zVFj0e51jzo0/Z++psXQYuDwRMs08L5cPg7wUihneLlbH3rsxtmniZXCd7SM7jBiCXnOcZgzDUp8F5XOuhfWxSd3rC7km5FtOSH+cEB3AdB04t89/1O/w1cDnyilFU='
    };
    const client = new line.Client(config);
//******************************************************************************
    
        
    var response = {
        statusCode: 200,
        headers: {},
        body: ""
    };
    
    var myData = {};

    var speechText = "";
    var requestJson = JSON.parse(event.body).request;
    var sessionJson = JSON.parse(event.body).session;
    var endFlg = false;
    
//=======================================================================
    if (requestJson.type === 'LaunchRequest') {
        // 起動時処理
        speechText = operationMessage;
        // フラグ初期化する
        endFlg = false;
//=======================================================================
    } else if (requestJson.type === 'SessionEndedRequest') {
        // セッション切れ
        speechText = endMessage;
        endFlg = true;
//=======================================================================
    } else if (requestJson.type === 'IntentRequest') {

        if (requestJson.intent.name === 'EndIntent' || 
            requestJson.intent.name === 'Clova.NoIntent' || 
            requestJson.intent.name === 'Clova.CancellIntent') {
            // 終了処理
            speechText = endMessage;
            endFlg = true;
//=======================================================================
        } else if (requestJson.intent.name === 'Clova.YesIntent') {
            // 「はい」と答えた場合
            speechText = operationMessage;
//=======================================================================
        } else if (requestJson.intent.name === 'Clova.GuideIntent') {
            // ヘルプ用
            speechText = operationMessage;
//=======================================================================
        } else if (requestJson.intent.name === 'NameIntent') {
            //名前のインテント
            speechText = "私の名前は「しん　みさき」です。";
            speechText += operationMessage;
            
            // LINEを送信する
            try {
                client.pushMessage(requestJson.session.userId, {
                    type: 'text',
                    text: `私の名前は漢字で書くと「新　美沙希」です。`,
                });
            } catch (error) {
                console.log(error);
            }

//=======================================================================
        } else if (requestJson.intent.name === 'AgeIntent') {
            //年齢のインテント
            speechText = "私の年齢は24歳です。";
            speechText += operationMessage;
//=======================================================================
        } else if (requestJson.intent.name === 'ComeFromIntent') {
            //出身のインテント
            speechText = "私の出身は滋賀県です。";
            speechText += operationMessage;

//=======================================================================
        } else if (requestJson.intent.name === 'HobbyIntent') {
            //趣味のインテント
            speechText = "私の趣味は音楽鑑賞です。";
            speechText += operationMessage;
        }
//=======================================================================
    }

    var responseJson = JSON.stringify({
        "version": "1.0",
        "sessionAttributes": myData,
        "response": {
            "outputSpeech": {
                "type": "SimpleSpeech",
                "values": {
                    "type":"PlainText",
                    "lang":"ja",
                    "value": speechText
                }
            },
            "card": {},
            "directives": [],
            "shouldEndSession": endFlg
        }
    });
    
    response.body = responseJson;
    
    callback(null, response);

};